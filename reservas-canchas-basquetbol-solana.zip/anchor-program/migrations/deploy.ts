// Migrations are an early feature. Currently, they're just a convenient
// place to store your deploy scripts.
import { AnchorProvider } from "@coral-xyz/anchor";

export default async function deploy(provider: AnchorProvider): Promise<void> {
  // No hay estado inicial que sembrar: las canchas las crean los
  // administradores con `crear_cancha` desde el cliente Java o el
  // frontend. Este archivo existe para que `anchor migrate` tenga un
  // punto de entrada estándar.
  console.log("Desplegando en:", provider.connection.rpcEndpoint);
  console.log("Wallet del desplegador:", provider.wallet.publicKey.toBase58());
}
