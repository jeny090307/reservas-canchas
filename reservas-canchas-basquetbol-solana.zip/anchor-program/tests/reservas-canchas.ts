import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { ReservasCanchas } from "../target/types/reservas_canchas";
import { PublicKey, Keypair } from "@solana/web3.js";
import { assert } from "chai";

/**
 * Pruebas on-chain del programa de reservas de canchas de básquetbol.
 *
 * Cubren los 5 casos de evidencia de docs/PRUEBAS_Y_EVIDENCIAS.md:
 *  E1 crear en horario libre -> Pendiente
 *  E2 doble reserva del mismo slot -> falla
 *  E3 cancelar por alguien que no es el dueño -> falla
 *  E4 cancelar con > 2 h de antelación -> cierra la cuenta
 *  E5 cancelar con < 2 h de antelación -> CancelacionNoPermitida
 * Además: confirmar (solo admin), cambiar de hora y completar.
 *
 * Nota de diseño: la fecha (`YYYY-MM-DD`) y el `inicio_unix` de cada
 * reserva siempre se corresponden. Por eso los horarios de prueba se
 * calculan a partir de la hora actual: `slot(horas)` devuelve la fecha,
 * la hora y el inicio en segundos del instante "ahora + horas".
 */

const PROGRAM_ID = new PublicKey(
  "BaRjCPQHBAyEYu8MGLTv9vwsofnrK6BqZcPAK3kKk2tZ"
);

interface Slot {
  fecha: string;
  hora: number;
  inicio: number;
}

/** Instante futuro "ahora + horas", descompuesto en fecha/hora/inicio. */
function slot(horasDesdeAhora: number): Slot {
  const d = new Date(Date.now() + horasDesdeAhora * 3600 * 1000);
  return {
    fecha: d.toISOString().slice(0, 10),
    hora: d.getUTCHours(),
    inicio: Math.floor(d.getTime() / 1000),
  };
}

function reservaPda(cancha: PublicKey, fecha: string, hora: number): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("reserva"),
      cancha.toBuffer(),
      Buffer.from(fecha),
      Buffer.from([hora]),
    ],
    PROGRAM_ID
  );
}

describe("reservas-canchas", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const program = anchor.workspace.ReservasCanchas as Program<ReservasCanchas>;

  const admin = Keypair.generate();
  const usuario = Keypair.generate();
  const otroUsuario = Keypair.generate();
  const cancha = Keypair.generate();

  // Horarios de prueba, todos en el futuro y con fecha/inicio coherentes.
  const slotA = slot(5); // E1, E2, confirmar, completar
  const slotB = slot(6); // E3, E4
  const slotC = slot(1); // E5 (menos de 2 h)
  const slotD = slot(7); // cambiar de hora (origen)
  const slotE = slot(8); // cambiar de hora (destino)

  before(async () => {
    // Fondea las wallets de prueba en devnet/localnet.
    for (const kp of [admin, usuario, otroUsuario]) {
      const sig = await provider.connection.requestAirdrop(kp.publicKey, 2_000_000_000);
      await provider.connection.confirmTransaction(sig);
    }
    await program.methods
      .crearCancha("Cancha Central", "Polideportivo Norte", new anchor.BN(150_000_000))
      .accounts({ cancha: cancha.publicKey, administrador: admin.publicKey })
      .signers([admin, cancha])
      .rpc();
  });

  it("E1: crea una reserva en un horario libre (estado Pendiente)", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotA.fecha, slotA.hora);
    await program.methods
      .crearReserva(slotA.fecha, slotA.hora, new anchor.BN(slotA.inicio))
      .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
      .signers([usuario])
      .rpc();

    const reserva = await program.account.reserva.fetch(pda);
    assert.equal(reserva.estado.pendiente !== undefined, true);
    assert.equal(reserva.horaInicio, slotA.hora);
    assert.isTrue(reserva.usuario.equals(usuario.publicKey));
  });

  it("E2: no permite reservar dos veces el mismo horario", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotA.fecha, slotA.hora);
    try {
      await program.methods
        .crearReserva(slotA.fecha, slotA.hora, new anchor.BN(slotA.inicio))
        .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: otroUsuario.publicKey })
        .signers([otroUsuario])
        .rpc();
      assert.fail("La doble reserva debería haber fallado");
    } catch (err) {
      assert.include(String(err), "already in use");
    }
  });

  it("confirma una reserva solo el administrador de la cancha", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotA.fecha, slotA.hora);
    await program.methods
      .confirmarReserva()
      .accounts({ reserva: pda, cancha: cancha.publicKey, administrador: admin.publicKey })
      .signers([admin])
      .rpc();
    const reserva = await program.account.reserva.fetch(pda);
    assert.equal(reserva.estado.confirmada !== undefined, true);
  });

  it("E3: un usuario que no es el dueño no puede cancelar la reserva", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotB.fecha, slotB.hora);
    await program.methods
      .crearReserva(slotB.fecha, slotB.hora, new anchor.BN(slotB.inicio))
      .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
      .signers([usuario])
      .rpc();

    try {
      await program.methods
        .cancelarReserva()
        .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: otroUsuario.publicKey })
        .signers([otroUsuario])
        .rpc();
      assert.fail("La cancelación por un tercero debería haber fallado");
    } catch (err) {
      assert.include(String(err), "AccesoNoAutorizado");
    }
  });

  it("E4: cancelar con más de 2 horas de antelación cierra la cuenta", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotB.fecha, slotB.hora);
    await program.methods
      .cancelarReserva()
      .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
      .signers([usuario])
      .rpc();

    const reserva = await program.account.reserva.fetchNullable(pda);
    assert.isNull(reserva, "La cuenta Reserva debería estar cerrada");
  });

  it("E5: cancelar con menos de 2 horas falla con CancelacionNoPermitida", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotC.fecha, slotC.hora);
    await program.methods
      .crearReserva(slotC.fecha, slotC.hora, new anchor.BN(slotC.inicio))
      .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
      .signers([usuario])
      .rpc();

    try {
      await program.methods
        .cancelarReserva()
        .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
        .signers([usuario])
        .rpc();
      assert.fail("La cancelación tardía debería haber fallado");
    } catch (err) {
      assert.include(String(err), "CancelacionNoPermitida");
    }
  });

  it("cambiar de hora mueve la reserva a la PDA del horario nuevo", async () => {
    const [pdaVieja] = reservaPda(cancha.publicKey, slotD.fecha, slotD.hora);
    const [pdaNueva] = reservaPda(cancha.publicKey, slotE.fecha, slotE.hora);
    await program.methods
      .crearReserva(slotD.fecha, slotD.hora, new anchor.BN(slotD.inicio))
      .accounts({ reserva: pdaVieja, cancha: cancha.publicKey, usuario: usuario.publicKey })
      .signers([usuario])
      .rpc();

    await program.methods
      .cambiarHora(slotE.hora, new anchor.BN(slotE.inicio))
      .accounts({
        reservaAntigua: pdaVieja,
        reservaNueva: pdaNueva,
        cancha: cancha.publicKey,
        usuario: usuario.publicKey,
      })
      .signers([usuario])
      .rpc();

    assert.isNull(await program.account.reserva.fetchNullable(pdaVieja));
    const nueva = await program.account.reserva.fetch(pdaNueva);
    assert.equal(nueva.horaInicio, slotE.hora);
  });

  it("completar y luego cancelar una reserva completada falla", async () => {
    const [pda] = reservaPda(cancha.publicKey, slotA.fecha, slotA.hora);
    await program.methods
      .completarReserva()
      .accounts({ reserva: pda, cancha: cancha.publicKey, administrador: admin.publicKey })
      .signers([admin])
      .rpc();
    try {
      await program.methods
        .cancelarReserva()
        .accounts({ reserva: pda, cancha: cancha.publicKey, usuario: usuario.publicKey })
        .signers([usuario])
        .rpc();
      assert.fail("Cancelar una reserva completada debería haber fallado");
    } catch (err) {
      assert.include(String(err), "CancelacionNoPermitida");
    }
  });
});
