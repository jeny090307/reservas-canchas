//! Programa de reservas de canchas de básquetbol en Solana.
//!
//! Cuentas:
//! * `Cancha`: la crea un administrador con una keypair generada por el
//!   cliente. Guarda nombre, ubicación, precio por hora y su administrador.
//! * `Reserva`: PDA derivada de las seeds
//!   `["reserva", cancha_pubkey, fecha, hora_inicio]`.
//!   La PDA es única por cancha + fecha + hora, por lo que un horario no
//!   se puede reservar dos veces: si la PDA ya existe, `crear_reserva`
//!   falla al intentar inicializarla.
//!
//! La fecha se guarda como texto `YYYY-MM-DD` (legible en el frontend) y
//! además como `inicio_unix` (segundos desde epoch, UTC), que es lo que
//! el programa usa para la regla de cancelación (> 2 horas de antelación).
//! El cliente calcula `inicio_unix` a partir de la fecha y la hora; el
//! programa nunca confía en un reloj enviado por el cliente: para la
//! cancelación usa el sysvar `Clock` on-chain.

use anchor_lang::prelude::*;
use anchor_lang::solana_program::sysvar::Sysvar;

declare_id!("BaRjCPQHBAyEYu8MGLTv9vwsofnrK6BqZcPAK3kKk2tZ");

/// Dos horas, en segundos. Una reserva solo puede cancelarse si faltan
/// más de `VENTANA_CANCELACION_SEGUNDOS` para su inicio.
pub const VENTANA_CANCELACION_SEGUNDOS: i64 = 2 * 3600;

#[program]
pub mod reservas_canchas {
    use super::*;

    /// Crea una cancha. Solo la firma quien paga la cuenta; ese firmante
    /// queda registrado como administrador de la cancha.
    pub fn crear_cancha(
        ctx: Context<CrearCancha>,
        nombre: String,
        ubicacion: String,
        precio_por_hora: u64,
    ) -> Result<()> {
        require!(nombre.len() <= 32, ErrorCode::TextoDemasiadoLargo);
        require!(ubicacion.len() <= 64, ErrorCode::TextoDemasiadoLargo);
        require!(precio_por_hora > 0, ErrorCode::PrecioInvalido);

        ctx.accounts.cancha.set_inner(Cancha {
            nombre,
            ubicacion,
            precio_por_hora,
            administrador: *ctx.accounts.administrador.key,
            activa: true,
        });
        Ok(())
    }

    /// Crea una reserva en estado Pendiente.
    ///
    /// La cuenta `reserva` es una PDA con seeds
    /// `["reserva", cancha, fecha, hora_inicio]`. Si esa PDA ya existe
    /// (el horario ya está reservado), la inicialización falla y la
    /// transacción se revierte: es la garantía on-chain contra la doble
    /// reserva, sin depender del frontend.
    pub fn crear_reserva(
        ctx: Context<CrearReserva>,
        fecha: String,
        hora_inicio: u8,
        inicio_unix: i64,
    ) -> Result<()> {
        require!(fecha.len() == 10, ErrorCode::FechaInvalida);
        require!(hora_inicio <= 23, ErrorCode::HoraInvalida);
        require!(ctx.accounts.cancha.activa, ErrorCode::CanchaInactiva);

        ctx.accounts.reserva.set_inner(Reserva {
            cancha: ctx.accounts.cancha.key(),
            usuario: *ctx.accounts.usuario.key,
            fecha,
            hora_inicio,
            inicio_unix,
            estado: EstadoReserva::Pendiente,
            bump: ctx.bumps.reserva,
        });
        Ok(())
    }

    /// Confirma una reserva Pendiente. Solo el administrador de la cancha.
    pub fn confirmar_reserva(ctx: Context<ConfirmarReserva>) -> Result<()> {
        let reserva = &mut ctx.accounts.reserva;
        require!(
            reserva.estado == EstadoReserva::Pendiente,
            ErrorCode::ReservaNoPendiente
        );
        reserva.estado = EstadoReserva::Confirmada;
        Ok(())
    }

    /// Cambia la hora de una reserva Pendiente. Solo su dueño.
    ///
    /// La hora forma parte de las seeds de la PDA, así que cambiarla
    /// significa cambiar de cuenta: la instrucción cierra la PDA antigua
    /// (devolviendo sus lamports al usuario) y crea la PDA nueva con las
    /// seeds del horario nuevo. Si el horario nuevo ya está ocupado, la
    /// inicialización de la PDA nueva falla y no se pierde la reserva
    /// antigua, porque la transacción completa se revierte.
    pub fn cambiar_hora(
        ctx: Context<CambiarHora>,
        nueva_hora_inicio: u8,
        nuevo_inicio_unix: i64,
    ) -> Result<()> {
        require!(nueva_hora_inicio <= 23, ErrorCode::HoraInvalida);
        let antigua = &ctx.accounts.reserva_antigua;
        require!(
            antigua.estado == EstadoReserva::Pendiente,
            ErrorCode::ReservaNoPendiente
        );
        require!(
            nueva_hora_inicio != antigua.hora_inicio,
            ErrorCode::HoraInvalida
        );

        ctx.accounts.reserva_nueva.set_inner(Reserva {
            cancha: antigua.cancha,
            usuario: antigua.usuario,
            fecha: antigua.fecha.clone(),
            hora_inicio: nueva_hora_inicio,
            inicio_unix: nuevo_inicio_unix,
            estado: EstadoReserva::Pendiente,
            bump: ctx.bumps.reserva_nueva,
        });
        Ok(())
    }

    /// Marca una reserva Confirmada como Completada (la cancha ya se usó).
    /// Solo el administrador de la cancha. Una reserva Completada ya no
    /// se puede cancelar: esa es la otra mitad de la regla de cierre.
    pub fn completar_reserva(ctx: Context<CompletarReserva>) -> Result<()> {
        let reserva = &mut ctx.accounts.reserva;
        require!(
            reserva.estado == EstadoReserva::Confirmada,
            ErrorCode::ReservaNoConfirmada
        );
        reserva.estado = EstadoReserva::Completada;
        Ok(())
    }

    /// Cancela una reserva y cierra su cuenta.
    ///
    /// Regla del programa (cierre condicionado): solo se cierra si
    /// faltan más de 2 horas para el inicio (`inicio_unix - ahora >
    /// 7200`) y el estado no es `Completada` (ni `Cancelada`). Si no se
    /// cumple, la transacción falla con `CancelacionNoPermitida` y la
    /// cuenta sigue existiendo. Al cerrarse, los lamports de la renta se
    /// devuelven al usuario (`close = usuario`).
    pub fn cancelar_reserva(ctx: Context<CancelarReserva>) -> Result<()> {
        let reserva = &ctx.accounts.reserva;
        require!(
            reserva.estado != EstadoReserva::Completada
                && reserva.estado != EstadoReserva::Cancelada,
            ErrorCode::CancelacionNoPermitida
        );
        let ahora = Clock::get()?.unix_timestamp;
        require!(
            reserva.inicio_unix - ahora > VENTANA_CANCELACION_SEGUNDOS,
            ErrorCode::CancelacionNoPermitida
        );
        // No hace falta poner estado = Cancelada: la cuenta se cierra
        // con `close = usuario` en el struct de cuentas.
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Cuentas
// ---------------------------------------------------------------------------

#[derive(Accounts)]
pub struct CrearCancha<'info> {
    #[account(
        init,
        payer = administrador,
        space = Cancha::SPACE,
    )]
    pub cancha: Account<'info, Cancha>,
    #[account(mut)]
    pub administrador: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(fecha: String, hora_inicio: u8)]
pub struct CrearReserva<'info> {
    #[account(
        init,
        payer = usuario,
        space = Reserva::SPACE,
        seeds = [b"reserva", cancha.key().as_ref(), fecha.as_bytes(), &[hora_inicio]],
        bump,
    )]
    pub reserva: Account<'info, Reserva>,
    #[account(mut)]
    pub cancha: Account<'info, Cancha>,
    #[account(mut)]
    pub usuario: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ConfirmarReserva<'info> {
    #[account(
        mut,
        has_one = cancha,
        constraint = administrador.key() == cancha.administrador
            @ ErrorCode::AccesoNoAutorizado,
    )]
    pub reserva: Account<'info, Reserva>,
    pub cancha: Account<'info, Cancha>,
    pub administrador: Signer<'info>,
}

#[derive(Accounts)]
#[instruction(nueva_hora_inicio: u8)]
pub struct CambiarHora<'info> {
    #[account(
        mut,
        close = usuario,
        has_one = cancha,
        has_one = usuario,
    )]
    pub reserva_antigua: Account<'info, Reserva>,
    #[account(
        init,
        payer = usuario,
        space = Reserva::SPACE,
        seeds = [b"reserva", cancha.key().as_ref(), reserva_antigua.fecha.as_bytes(), &[nueva_hora_inicio]],
        bump,
    )]
    pub reserva_nueva: Account<'info, Reserva>,
    pub cancha: Account<'info, Cancha>,
    #[account(mut)]
    pub usuario: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CompletarReserva<'info> {
    #[account(
        mut,
        has_one = cancha,
        constraint = administrador.key() == cancha.administrador
            @ ErrorCode::AccesoNoAutorizado,
    )]
    pub reserva: Account<'info, Reserva>,
    pub cancha: Account<'info, Cancha>,
    pub administrador: Signer<'info>,
}

#[derive(Accounts)]
pub struct CancelarReserva<'info> {
    #[account(
        mut,
        close = usuario,
        has_one = cancha,
        has_one = usuario,
    )]
    pub reserva: Account<'info, Reserva>,
    pub cancha: Account<'info, Cancha>,
    #[account(mut)]
    pub usuario: Signer<'info>,
}

// ---------------------------------------------------------------------------
// Datos guardados en las cuentas
// ---------------------------------------------------------------------------

#[account]
pub struct Cancha {
    /// Nombre de la cancha, máx. 32 caracteres.
    pub nombre: String,
    /// Ubicación, máx. 64 caracteres.
    pub ubicacion: String,
    /// Precio por hora, en lamports.
    pub precio_por_hora: u64,
    /// Wallet del administrador que la creó.
    pub administrador: Pubkey,
    /// Si es false, no se aceptan reservas nuevas.
    pub activa: bool,
}

impl Cancha {
    /// 8 (discriminador) + (4 + 32) nombre + (4 + 64) ubicación
    /// + 8 precio + 32 administrador + 1 activa.
    pub const SPACE: usize = 8 + 36 + 68 + 8 + 32 + 1;
}

#[account]
pub struct Reserva {
    /// Cancha reservada.
    pub cancha: Pubkey,
    /// Wallet del usuario que reservó.
    pub usuario: Pubkey,
    /// Fecha en formato `YYYY-MM-DD`.
    pub fecha: String,
    /// Hora de inicio (0-23).
    pub hora_inicio: u8,
    /// Inicio de la reserva en segundos desde epoch (UTC).
    pub inicio_unix: i64,
    /// Estado actual de la reserva.
    pub estado: EstadoReserva,
    /// Bump de la PDA.
    pub bump: u8,
}

impl Reserva {
    /// 8 (discriminador) + 32 cancha + 32 usuario + (4 + 10) fecha
    /// + 1 hora_inicio + 8 inicio_unix + 1 estado + 1 bump.
    pub const SPACE: usize = 8 + 32 + 32 + 14 + 1 + 8 + 1 + 1;
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum EstadoReserva {
    Pendiente,
    Confirmada,
    Completada,
    Cancelada,
}

// ---------------------------------------------------------------------------
// Errores propios del programa
// ---------------------------------------------------------------------------

#[error_code]
pub enum ErrorCode {
    #[msg("Solo el administrador o el dueño pueden realizar esta operación.")]
    AccesoNoAutorizado,
    #[msg("La cancelación no está permitida: faltan menos de 2 horas para el inicio o la reserva ya está completada/cancelada.")]
    CancelacionNoPermitida,
    #[msg("La reserva no está en estado Pendiente.")]
    ReservaNoPendiente,
    #[msg("La reserva no está en estado Confirmada.")]
    ReservaNoConfirmada,
    #[msg("La hora de inicio debe estar entre 0 y 23.")]
    HoraInvalida,
    #[msg("La fecha debe tener formato YYYY-MM-DD (10 caracteres).")]
    FechaInvalida,
    #[msg("La cancha no está activa.")]
    CanchaInactiva,
    #[msg("El precio por hora debe ser mayor que cero.")]
    PrecioInvalido,
    #[msg("El texto supera la longitud máxima permitida.")]
    TextoDemasiadoLargo,
}
