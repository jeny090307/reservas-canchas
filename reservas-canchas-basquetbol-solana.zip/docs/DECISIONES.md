# Decisiones de diseño

## 1. El programa es Rust/Anchor y el resto es Java

Los programas de Solana no se pueden escribir en Java: el runtime
solo ejecuta programas compilados a BPF, y Anchor genera ese código
desde Rust. Por eso la única parte en Rust es el programa on-chain.
El cliente y el frontend están en Java (Java 17, Maven, solanaj y
JavaFX 21) porque es el lenguaje que pidió el proyecto, y porque en
Solana el cliente puede estar en cualquier lenguaje: lo único que
importa es que construya las transacciones exactamente como describe
la IDL.

## 2. La reserva es una PDA, la cancha no

La `Reserva` es una PDA con seeds `["reserva", cancha, fecha,
hora_inicio]` porque su identidad **es** su horario: dos reservas
del mismo horario deben ser la misma cuenta, y eso hace imposible la
doble reserva sin necesidad de un índice ni de una comprobación
extra. La `Cancha`, en cambio, se crea con una keypair generada por
el cliente, como cualquier cuenta Anchor normal: su identidad no
depende de ningún dato previo.

## 3. La fecha se guarda dos veces: texto e `inicio_unix`

`fecha` se guarda como texto `YYYY-MM-DD` porque es legible en el
frontend y en las pruebas, y porque forma parte de las seeds de la
PDA. Pero el programa no puede calcular "faltan 2 horas" a partir
de un texto, así que también guarda `inicio_unix` (segundos desde
epoch, UTC), calculado por el cliente al crear la reserva. La regla
de cancelación usa `inicio_unix` y el sysvar `Clock` on-chain, nunca
un reloj enviado por el cliente: un cliente malicioso no puede
mentir sobre la hora para cancelar tarde.

## 4. Cambiar de hora cierra la PDA antigua y crea una nueva

La hora forma parte de las seeds, así que una reserva no puede
"cambiar de dirección". La instrucción `cambiar_hora` cierra la PDA
antigua (`close = usuario`, que devuelve sus lamports) y crea la PDA
del horario nuevo en la misma transacción. Si el horario nuevo ya
está ocupado, la inicialización de la PDA nueva falla y la
transacción completa se revierte, así que la reserva antigua no se
pierde. La alternativa —guardar la hora solo como campo y mantener
la PDA original— habría roto la garantía de unicidad del horario.

## 5. El cierre es condicionado y devuelve los lamports

`cancelar_reserva` usa `close = usuario`: al cerrarse la cuenta, la
renta que pagó el usuario vuelve a su wallet. Pero el cierre solo
ocurre si se cumplen dos condiciones del programa: faltan más de 2
horas para el inicio y el estado no es `Completada` (ni `Cancelada`).
Si no se cumplen, la transacción falla con el error propio
`CancelacionNoPermitida` y la cuenta sigue existiendo. El cliente
replica la regla en `Reserva.esCancelacionPermitida` para no enviar
transacciones que van a fallar, pero la regla autoritativa es la
on-chain.

## 6. El cliente Java codifica las instrucciones a mano (Borsh)

El cliente no usa el SDK de Anchor (que es de TypeScript), así que
codifica cada instrucción como lo haría Anchor: discriminador =
primeros 8 bytes de `SHA-256("global:<nombre>")`, argumentos en
Borsh (String = longitud u32 little-endian + UTF-8, u64/i64 en
little-endian, u8 en 1 byte) y cuentas en el mismo orden que la IDL.
Las pruebas unitarias comprueban los discriminadores contra la IDL
y la derivación de PDA contra las mismas seeds del programa.

## 7. No hay índice on-chain de reservas

Solana no ofrece "dame todas las reservas de una cancha". El
cliente Java las lista derivando la PDA de cada hora del día (0-23)
y leyendo las que existen (`listarReservas`). Es determinista y
suficiente para este proyecto. En producción se usaría
`getProgramAccounts` con filtros por `cancha` o un indexador
externo; el frontend guarda además una lista local de canchas
conocidas por la misma razón.

## 8. Perfil de usuario = clave pública

No se creó una cuenta `PerfilUsuario` separada: la identidad del
usuario es su clave pública, ya guardada en cada reserva y en cada
cancha. Añadirla después no rompe nada (sería una PDA con seed
`["perfil", usuario]`), y se documenta en el caso de uso como
extensión posible.

## 9. Wallet solo de devnet en el frontend

El frontend conecta la wallet cargando un keypair local en formato
JSON de Solana CLI. Es solo para la demostración en devnet: en una
app real la clave privada nunca saldría de la extensión de wallet
(Phantom/Solflare). Por eso el `.gitignore` bloquea keypairs y
archivos `.env`, y `WalletService` lo advierte en su documentación.

## 10. Reutilización de plantillas

Se reutiliza la plantilla estándar de Anchor (`anchor init`), la
estructura Maven habitual y las librerías solanaj, Gson, JUnit 5 y
JavaFX. No se reinventó el RPC, la codificación Base58 del cliente
es propia y mínima (solo para mostrar claves públicas), y todo lo
demás usa librerías mantenidas.
