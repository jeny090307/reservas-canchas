# Pruebas y evidencias

Cada operación del proyecto tiene su caso de prueba. La tabla
corresponde operación → prueba → evidencia esperada. Los 5 casos de
evidencia son E1-E5.

## Mapa operación → prueba

| Operación | Prueba Anchor (`tests/reservas-canchas.ts`) | Prueba Java (`ReservaClientTest.java`) | Evidencia esperada |
| --- | --- | --- | --- |
| Crear cancha | `before` (crea "Cancha Central") | — | La cuenta Cancha existe con su administrador |
| **Crear reserva** | E1 | — | Reserva en estado `Pendiente`, con su usuario y su hora |
| **Leer reserva/cancha** | `fetch` en E1, E4 | Decodificación Borsh | Los campos leídos coinciden con los enviados |
| **Modificar (confirmar)** | "confirma una reserva solo el administrador" | — | Estado pasa de `Pendiente` a `Confirmada` |
| **Modificar (cambiar hora)** | "cambiar de hora mueve la reserva a la PDA del horario nuevo" | — | La PDA antigua queda cerrada y la nueva existe con la hora nueva |
| **Modificar (completar)** | "completar y luego cancelar una reserva completada falla" | — | Estado pasa a `Completada` |
| **Permisos** | E3 | — | Un tercero no puede cancelar: `AccesoNoAutorizado` |
| **Cierre condicionado** | E4, E5 | Regla de cancelación (> 2 h) | Ver abajo |
| **PDA / IDL coherentes** | `reservaPda` en todos los casos | Derivación de PDA + discriminadores | Misma seed → misma PDA en Rust, TS y Java |

## Los 5 casos de evidencia

### E1 — Crear en horario libre: éxito
- **Acción:** crear una reserva para una cancha, fecha y hora libres.
- **Evidencia:** la cuenta Reserva existe, su estado es `Pendiente`,
  su `usuario` es quien firmó y su `horaInicio` es la pedida.
- **Dónde:** `tests/reservas-canchas.ts` → "E1: crea una reserva en un
  horario libre".

### E2 — Doble reserva del mismo horario: falla
- **Acción:** crear una segunda reserva con la misma cancha, fecha y
  hora que una ya existente.
- **Evidencia:** la transacción falla porque la PDA ya está en uso
  (`already in use`); la reserva original no cambia.
- **Dónde:** `tests/reservas-canchas.ts` → "E2: no permite reservar
  dos veces el mismo horario".

### E3 — Cancelar por alguien que no es el dueño: falla
- **Acción:** un usuario distinto al dueño intenta `cancelar_reserva`.
- **Evidencia:** la transacción falla con `AccesoNoAutorizado`
  (restricción `has_one = usuario`); la reserva sigue existiendo.
- **Dónde:** `tests/reservas-canchas.ts` → "E3: un usuario que no es
  el dueño no puede cancelar la reserva".

### E4 — Cancelar con más de 2 horas: éxito y cierre de cuenta
- **Acción:** el dueño cancela una reserva cuyo inicio es dentro de
  más de 2 horas.
- **Evidencia:** `fetchNullable` devuelve `null`: la cuenta Reserva
  está cerrada y sus lamports volvieron al usuario.
- **Dónde:** `tests/reservas-canchas.ts` → "E4: cancelar con más de 2
  horas de antelación cierra la cuenta". En Java:
  `cancelacionPermitidaConMasDeDosHoras`.

### E5 — Cancelar con menos de 2 horas: falla
- **Acción:** el dueño cancela una reserva cuyo inicio es dentro de
  1 hora.
- **Evidencia:** la transacción falla con el error propio
  `CancelacionNoPermitida` y la cuenta sigue existiendo.
- **Dónde:** `tests/reservas-canchas.ts` → "E5: cancelar con menos
  de 2 horas falla con CancelacionNoPermitida". En Java:
  `cancelacionRechazadaConMenosDeDosHoras` (incluye el caso límite:
  exactamente 2 horas tampoco basta) y
  `cancelacionRechazadaSiEstaCompletada`.

## Cómo ejecutarlas

```bash
# Pruebas on-chain (necesitan Anchor y un validador local o devnet)
cd anchor-program
anchor test

# Pruebas unitarias Java (puras, sin red)
cd java-client
mvn test
```

## Cómo revisarlas (checklist para el revisor)

1. `anchor build` compila sin errores y la IDL generada en
   `target/idl/reservas_canchas.json` coincide con la archivada en
   `anchor-program/idl/reservas_canchas.json` (mismos nombres de
   instrucciones, cuentas y discriminadores).
2. `anchor test` pasa los 8 casos, incluidos E1-E5.
3. `mvn test` en `java-client` pasa: la PDA derivada en Java es la
   misma que en Rust/TS para las mismas seeds, y los discriminadores
   coinciden con la IDL.
4. En el frontend, crear una reserva en un horario libre funciona;
   intentar el mismo horario dos veces muestra el error; cancelar
   con más de 2 horas cierra la reserva y con menos de 2 horas
   muestra el error de cancelación no permitida.
