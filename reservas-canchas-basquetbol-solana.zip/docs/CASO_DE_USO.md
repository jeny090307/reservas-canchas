# Caso de uso: reservas de canchas de básquetbol

## Actores

| Actor | Qué hace |
| --- | --- |
| **Administrador de cancha** | Crea canchas, confirma reservas y marca reservas como completadas. |
| **Jugador (usuario con wallet)** | Consulta canchas y horarios libres, crea reservas, cambia la hora de sus reservas pendientes y las cancela. |
| **Programa `reservas_canchas`** | Guarda las cuentas, aplica las reglas y rechaza lo que no cumple. |

## Entidades (cuentas on-chain)

### Cancha

Cuenta creada con una keypair generada por el cliente (no es PDA).
Campos: `nombre` (máx. 32 caracteres), `ubicacion` (máx. 64),
`precio_por_hora` (lamports), `administrador` (clave pública de quien
la creó) y `activa` (bool).

### Reserva

Cuenta PDA derivada de las seeds:

```
["reserva", cancha_pubkey, fecha, hora_inicio]
```

Campos: `cancha`, `usuario`, `fecha` (`YYYY-MM-DD`), `hora_inicio`
(0-23), `inicio_unix` (segundos desde epoch, UTC), `estado`
(`Pendiente` / `Confirmada` / `Completada` / `Cancelada`) y `bump`.

La PDA es única por cancha + fecha + hora: esa es la garantía
on-chain de que un horario no se reserve dos veces.

### PerfilUsuario

El ejemplo de clase mencionaba un perfil de usuario. En este proyecto
el perfil no es una cuenta separada: la identidad del usuario es su
clave pública, que ya queda guardada en cada `Reserva` (campo
`usuario`) y en cada `Cancha` (campo `administrador`). Si el proyecto
crece, se puede añadir una cuenta `PerfilUsuario` (PDA con seed
`["perfil", usuario]`) con nombre y contador de reservas, sin tocar
las instrucciones existentes.

## Flujo principal

1. El administrador conecta su wallet y crea una cancha
   (`crear_cancha`). La cancha queda activa.
2. Un jugador conecta su wallet, elige una cancha, una fecha y una
   hora. El frontend deriva la PDA de esa reserva y lee si existe:
   si existe, el horario está ocupado; si no, está libre.
3. El jugador crea la reserva (`crear_reserva`). Queda en estado
   `Pendiente`.
4. El administrador la confirma (`confirmar_reserva`): pasa a
   `Confirmada`.
5. Después del partido, el administrador la marca como
   `Completada` (`completar_reserva`).
6. Si el jugador ya no puede ir, puede cancelarla
   (`cancelar_reserva`), pero solo si faltan más de 2 horas para el
   inicio y la reserva no está `Completada`. Al cancelarse, la cuenta
   se cierra y los lamports de la renta vuelven a su wallet.

## Flujos alternos

- **Cambiar de hora:** el dueño de una reserva `Pendiente` puede
  moverla a otro horario (`cambiar_hora`). Como la hora forma parte
  de las seeds de la PDA, la instrucción cierra la PDA antigua y crea
  la PDA del horario nuevo en la misma transacción. Si el horario
  nuevo ya está ocupado, todo se revierte y no se pierde la reserva.
- **Horario ocupado:** crear una reserva sobre una PDA que ya existe
  falla on-chain. El frontend lo detecta antes, al leer la PDA.
- **Cancelación tardía:** si faltan 2 horas o menos, o la reserva ya
  está `Completada`, la cancelación falla con
  `CancelacionNoPermitida` y la cuenta sigue existiendo.
- **Permisos:** confirmar o completar una reserva que no es de tu
  cancha falla; cancelar o cambiar la hora de una reserva que no es
  tuya falla. El programa lo verifica con `has_one` y con la
  comparación de la clave del firmante.

## Reglas de negocio (resumen)

| Regla | Dónde se impone |
| --- | --- |
| Un horario, una sola reserva | PDA única por cancha + fecha + hora |
| Solo el admin crea canchas y confirma | Firmante = `administrador` de la Cancha |
| Solo el dueño cambia/cancela su reserva | Firmante = `usuario` de la Reserva |
| Solo se cambia la hora si está Pendiente | `require!(estado == Pendiente)` |
| Solo se cancela con > 2 h de antelación | `inicio_unix - ahora > 7200` (Clock sysvar) |
| No se cancela una reserva Completada | `require!(estado != Completada)` |
