package com.reservas.ui;

import com.reservas.solana.ReservaClient;
import com.reservas.solana.SolanaConfig;
import com.reservas.solana.model.Cancha;
import com.reservas.solana.model.Reserva;
import com.reservas.solana.wallet.WalletService;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.p2p.solanaj.core.Account;
import org.p2p.solanaj.core.PublicKey;

/**
 * Capa de servicio entre la interfaz JavaFX y el cliente Java de Solana.
 *
 * No contiene código de interfaz: recibe llamadas desde el controlador,
 * las ejecuta contra devnet y devuelve los datos ya decodificados.
 * Las llamadas a la red son bloqueantes, por eso el controlador las
 * ejecuta en hilos de fondo (ver {@link MainController}).
 *
 * <p>Como Solana no ofrece un índice on-chain de canchas, el frontend
 * mantiene una lista local de canchas conocidas: las que el usuario
 * crea aquí y las que añade pegando su clave pública. Es una
 * limitación conocida, documentada en {@code docs/DECISIONES.md}.</p>
 */
public class ReservaService {

    private final ReservaClient cliente;
    private final WalletService wallet = new WalletService();
    private final List<PublicKey> canchasConocidas = new ArrayList<>();

    public ReservaService() {
        this(new SolanaConfig());
    }

    public ReservaService(SolanaConfig config) {
        this.cliente = new ReservaClient(config);
    }

    // -- Wallet ----------------------------------------------------------

    public PublicKey conectarWallet(Path archivoKeypair) throws Exception {
        return wallet.conectar(archivoKeypair);
    }

    public void desconectarWallet() {
        wallet.desconectar();
    }

    public boolean hayWalletConectada() {
        return wallet.estaConectado();
    }

    public Optional<PublicKey> getWalletPublicKey() {
        return wallet.getPublicKey();
    }

    public PublicKey getProgramId() {
        return cliente.getProgramId();
    }

    private Account cuentaFirmante() {
        return wallet.getCuenta();
    }

    // -- Canchas ---------------------------------------------------------

    public PublicKey crearCancha(String nombre, String ubicacion, long precioPorHoraLamports) {
        PublicKey cancha = cliente.crearCancha(
                cuentaFirmante(), nombre, ubicacion, precioPorHoraLamports);
        canchasConocidas.add(cancha);
        return cancha;
    }

    public void agregarCanchaConocida(PublicKey cancha) {
        if (!canchasConocidas.contains(cancha)) {
            canchasConocidas.add(cancha);
        }
    }

    public List<PublicKey> getCanchasConocidas() {
        return List.copyOf(canchasConocidas);
    }

    public Optional<Cancha> leerCancha(PublicKey cancha) {
        return cliente.leerCancha(cancha);
    }

    // -- Reservas --------------------------------------------------------

    public String crearReserva(PublicKey cancha, String fecha, int horaInicio) {
        return cliente.crearReserva(cuentaFirmante(), cancha, fecha, horaInicio);
    }

    public String confirmarReserva(PublicKey reserva, PublicKey cancha) {
        return cliente.confirmarReserva(cuentaFirmante(), reserva, cancha);
    }

    public String cambiarHora(PublicKey cancha, String fecha, int horaAntigua, int horaNueva) {
        return cliente.cambiarHora(cuentaFirmante(), cancha, fecha, horaAntigua, horaNueva);
    }

    public String completarReserva(PublicKey reserva, PublicKey cancha) {
        return cliente.completarReserva(cuentaFirmante(), reserva, cancha);
    }

    public String cancelarReserva(PublicKey reserva, PublicKey cancha) {
        return cliente.cancelarReserva(cuentaFirmante(), reserva, cancha);
    }

    public List<Reserva> listarReservas(PublicKey cancha, String fecha) {
        return cliente.listarReservas(cancha, fecha);
    }
}
