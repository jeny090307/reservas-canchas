package com.reservas.ui;

import java.io.File;
import java.nio.file.Path;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.p2p.solanaj.core.PublicKey;

/**
 * Lógica de la sección de wallet de la ventana principal.
 *
 * No es el controlador FXML (ese es {@link MainController}): es una
 * clase de ayuda a la que el controlador principal delega los botones
 * de conectar/desconectar, para que esa lógica no se mezcle con la de
 * reservas. Recibe los controles ya creados por el FXML.
 *
 * La wallet se conecta cargando un keypair local en formato JSON de
 * Solana CLI, solo para la demostración en devnet (ver
 * {@code WalletService}: nunca usar un keypair de mainnet aquí).
 */
public class WalletController {

    private final ReservaService servicio;
    private final Label walletLabel;
    private final Button conectarButton;
    private final Button desconectarButton;
    private Runnable alCambiarWallet = () -> {
    };

    public WalletController(ReservaService servicio, Label walletLabel,
                            Button conectarButton, Button desconectarButton) {
        this.servicio = servicio;
        this.walletLabel = walletLabel;
        this.conectarButton = conectarButton;
        this.desconectarButton = desconectarButton;
        // Los botones los cablea MainController con onAction en el FXML;
        // esta clase solo contiene la lógica de conectar/desconectar.
        actualizarEstado();
    }

    /** Acción que se ejecuta cada vez que cambia el estado de la wallet. */
    public void setAlCambiarWallet(Runnable accion) {
        this.alCambiarWallet = accion;
    }

    public void conectar(Stage escenario) {
        FileChooser selector = new FileChooser();
        selector.setTitle("Elige tu keypair de devnet (JSON de Solana CLI)");
        selector.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Keypair JSON", "*.json"));
        File archivo = selector.showOpenDialog(escenario);
        if (archivo == null) {
            return;
        }
        try {
            PublicKey publica = servicio.conectarWallet(Path.of(archivo.getAbsolutePath()));
            walletLabel.setText("Wallet conectada: " + publica.toBase58());
            actualizarEstado();
            alCambiarWallet.run();
        } catch (Exception e) {
            walletLabel.setText("No se pudo conectar la wallet: " + e.getMessage());
        }
    }

    public void desconectar() {
        servicio.desconectarWallet();
        walletLabel.setText("Wallet no conectada");
        actualizarEstado();
        alCambiarWallet.run();
    }

    private void actualizarEstado() {
        boolean conectada = servicio.hayWalletConectada();
        conectarButton.setDisable(conectada);
        desconectarButton.setDisable(!conectada);
    }
}
