package com.reservas.ui;

import com.reservas.solana.model.Reserva;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.p2p.solanaj.core.PublicKey;

/**
 * Controlador de la ventana principal (main.fxml).
 *
 * Las llamadas a Solana son bloqueantes, así que todas se ejecutan en
 * hilos de fondo con {@link Task} y solo actualizan la interfaz con
 * {@code Platform.runLater} (a través de los handlers de la tarea).
 * La wallet se gestiona con {@link WalletController}.
 */
public class MainController {

    private final ReservaService servicio = new ReservaService();
    private WalletController walletController;
    private PublicKey canchaSeleccionada;

    @FXML private Label walletLabel;
    @FXML private Button conectarButton;
    @FXML private Button desconectarButton;
    @FXML private ListView<String> canchasListView;
    @FXML private TextField canchaPubkeyField;
    @FXML private Button agregarCanchaButton;
    @FXML private Button crearCanchaButton;
    @FXML private DatePicker fechaPicker;
    @FXML private ChoiceBox<Integer> horaChoiceBox;
    @FXML private Button crearReservaButton;
    @FXML private TableView<Reserva> reservasTable;
    @FXML private TableColumn<Reserva, String> colFecha;
    @FXML private TableColumn<Reserva, Integer> colHora;
    @FXML private TableColumn<Reserva, String> colEstado;
    @FXML private TableColumn<Reserva, String> colUsuario;
    @FXML private Button confirmarButton;
    @FXML private Button cancelarButton;
    @FXML private Button cambiarHoraButton;
    @FXML private Button completarButton;
    @FXML private Label estadoLabel;

    @FXML
    public void initialize() {
        walletController = new WalletController(servicio, walletLabel, conectarButton, desconectarButton);
        walletController.setAlCambiarWallet(this::actualizarBotones);

        for (int hora = 0; hora < 24; hora++) {
            horaChoiceBox.getItems().add(hora);
        }
        horaChoiceBox.setValue(18);
        fechaPicker.setValue(LocalDate.now());

        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        colHora.setCellValueFactory(new PropertyValueFactory<>("horaInicio"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colUsuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));

        canchasListView.getSelectionModel().selectedItemProperty().addListener(
                (observable, anterior, seleccionada) -> {
                    canchaSeleccionada = seleccionada == null
                            ? null : new PublicKey(seleccionada);
                    cargarReservas();
                    actualizarBotones();
                });
        actualizarBotones();
    }

    // -- Wallet (delegado) -------------------------------------------------

    @FXML
    public void onConectarWallet() {
        walletController.conectar(
                (Stage) conectarButton.getScene().getWindow());
    }

    @FXML
    public void onDesconectarWallet() {
        walletController.desconectar();
    }

    // -- Canchas -----------------------------------------------------------

    @FXML
    public void onAgregarCancha() {
        try {
            PublicKey cancha = new PublicKey(canchaPubkeyField.getText().trim());
            servicio.agregarCanchaConocida(cancha);
            refrescarListaCanchas();
            estadoLabel.setText("Cancha agregada: " + cancha.toBase58());
        } catch (Exception e) {
            estadoLabel.setText("Clave pública inválida: " + e.getMessage());
        }
    }

    @FXML
    public void onCrearCancha() {
        if (!servicio.hayWalletConectada()) {
            estadoLabel.setText("Conecta primero tu wallet.");
            return;
        }
        TextInputDialog nombreDialogo = new TextInputDialog("Cancha Central");
        nombreDialogo.setHeaderText("Nombre de la cancha");
        Optional<String> nombre = nombreDialogo.showAndWait();
        if (nombre.isEmpty()) {
            return;
        }
        TextInputDialog ubicacionDialogo = new TextInputDialog("Polideportivo Norte");
        ubicacionDialogo.setHeaderText("Ubicación de la cancha");
        Optional<String> ubicacion = ubicacionDialogo.showAndWait();
        if (ubicacion.isEmpty()) {
            return;
        }
        TextInputDialog precioDialogo = new TextInputDialog("0.15");
        precioDialogo.setHeaderText("Precio por hora (en SOL)");
        Optional<String> precioTexto = precioDialogo.showAndWait();
        if (precioTexto.isEmpty()) {
            return;
        }
        double precioSol;
        try {
            precioSol = Double.parseDouble(precioTexto.get());
        } catch (NumberFormatException e) {
            estadoLabel.setText("El precio debe ser un número, por ejemplo 0.15.");
            return;
        }
        long precioLamports = (long) (precioSol * 1_000_000_000L);
        ejecutarEnFondo(() -> {
            PublicKey cancha = servicio.crearCancha(nombre.get(), ubicacion.get(), precioLamports);
            Platform.runLater(() -> {
                refrescarListaCanchas();
                canchasListView.getSelectionModel().select(cancha.toBase58());
                estadoLabel.setText("Cancha creada: " + cancha.toBase58());
            });
        }, "No se pudo crear la cancha");
    }

    // -- Reservas ----------------------------------------------------------

    @FXML
    public void onCrearReserva() {
        if (!servicio.hayWalletConectada() || canchaSeleccionada == null
                || fechaPicker.getValue() == null || horaChoiceBox.getValue() == null) {
            estadoLabel.setText("Conecta la wallet, elige una cancha, una fecha y una hora.");
            return;
        }
        String fecha = fechaPicker.getValue().toString();
        int hora = horaChoiceBox.getValue();
        ejecutarEnFondo(() -> {
            String firma = servicio.crearReserva(canchaSeleccionada, fecha, hora);
            Platform.runLater(() -> {
                estadoLabel.setText("Reserva creada (Pendiente). Tx: " + firma);
                cargarReservas();
            });
        }, "No se pudo crear la reserva (¿horario ya ocupado?)");
    }

    @FXML
    public void onConfirmarReserva() {
        Reserva reserva = reservasTable.getSelectionModel().getSelectedItem();
        if (reserva == null) {
            estadoLabel.setText("Selecciona una reserva de la tabla.");
            return;
        }
        ejecutarEnFondo(() -> {
            String firma = servicio.confirmarReserva(
                    derivarPda(reserva), new PublicKey(reserva.getCancha()));
            Platform.runLater(() -> {
                estadoLabel.setText("Reserva confirmada. Tx: " + firma);
                cargarReservas();
            });
        }, "No se pudo confirmar la reserva (¿no eres el administrador?)");
    }

    @FXML
    public void onCancelarReserva() {
        Reserva reserva = reservasTable.getSelectionModel().getSelectedItem();
        if (reserva == null) {
            estadoLabel.setText("Selecciona una reserva de la tabla.");
            return;
        }
        ejecutarEnFondo(() -> {
            String firma = servicio.cancelarReserva(
                    derivarPda(reserva), new PublicKey(reserva.getCancha()));
            Platform.runLater(() -> {
                estadoLabel.setText("Reserva cancelada y cuenta cerrada. Tx: " + firma);
                cargarReservas();
            });
        }, "No se pudo cancelar (¿menos de 2 horas o no eres el dueño?)");
    }

    @FXML
    public void onCambiarHora() {
        Reserva reserva = reservasTable.getSelectionModel().getSelectedItem();
        if (reserva == null || horaChoiceBox.getValue() == null) {
            estadoLabel.setText("Selecciona una reserva y una hora nueva.");
            return;
        }
        int horaNueva = horaChoiceBox.getValue();
        ejecutarEnFondo(() -> {
            String firma = servicio.cambiarHora(new PublicKey(reserva.getCancha()),
                    reserva.getFecha(), reserva.getHoraInicio(), horaNueva);
            Platform.runLater(() -> {
                estadoLabel.setText("Hora cambiada a las " + horaNueva + ":00. Tx: " + firma);
                cargarReservas();
            });
        }, "No se pudo cambiar la hora (¿horario nuevo ocupado o reserva no Pendiente?)");
    }

    @FXML
    public void onCompletarReserva() {
        Reserva reserva = reservasTable.getSelectionModel().getSelectedItem();
        if (reserva == null) {
            estadoLabel.setText("Selecciona una reserva de la tabla.");
            return;
        }
        ejecutarEnFondo(() -> {
            String firma = servicio.completarReserva(
                    derivarPda(reserva), new PublicKey(reserva.getCancha()));
            Platform.runLater(() -> {
                estadoLabel.setText("Reserva completada. Tx: " + firma);
                cargarReservas();
            });
        }, "No se pudo completar la reserva (¿no está Confirmada?)");
    }

    // -- Ayudas ------------------------------------------------------------

    private PublicKey derivarPda(Reserva reserva) {
        return com.reservas.solana.PdaUtils.derivarReserva(
                new PublicKey(reserva.getCancha()), reserva.getFecha(),
                reserva.getHoraInicio(), servicio.getProgramId()).getAddress();
    }

    private void refrescarListaCanchas() {
        List<String> claves = servicio.getCanchasConocidas().stream()
                .map(PublicKey::toBase58)
                .toList();
        canchasListView.setItems(FXCollections.observableArrayList(claves));
    }

    private void cargarReservas() {
        if (canchaSeleccionada == null || fechaPicker.getValue() == null) {
            reservasTable.setItems(FXCollections.emptyObservableList());
            return;
        }
        String fecha = fechaPicker.getValue().toString();
        ejecutarEnFondo(() -> {
            List<Reserva> reservas = servicio.listarReservas(canchaSeleccionada, fecha);
            Platform.runLater(() ->
                    reservasTable.setItems(FXCollections.observableArrayList(reservas)));
        }, "No se pudieron leer las reservas");
    }

    private void actualizarBotones() {
        boolean conectada = servicio.hayWalletConectada();
        crearCanchaButton.setDisable(!conectada);
        crearReservaButton.setDisable(!conectada || canchaSeleccionada == null);
        confirmarButton.setDisable(!conectada);
        cancelarButton.setDisable(!conectada);
        cambiarHoraButton.setDisable(!conectada);
        completarButton.setDisable(!conectada);
    }

    /**
     * Ejecuta trabajo de red en un hilo de fondo. Si falla, muestra el
     * mensaje de error en la etiqueta de estado, sin congelar la UI.
     */
    private void ejecutarEnFondo(Runnable trabajo, String mensajeError) {
        Task<Void> tarea = new Task<>() {
            @Override
            protected Void call() {
                trabajo.run();
                return null;
            }
        };
        tarea.setOnFailed(evento -> Platform.runLater(()
                -> estadoLabel.setText(mensajeError + " "
                        + tarea.getException().getMessage())));
        new Thread(tarea).start();
    }
}
