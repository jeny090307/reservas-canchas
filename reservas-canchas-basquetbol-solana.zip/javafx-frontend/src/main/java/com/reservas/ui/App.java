package com.reservas.ui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Punto de entrada del frontend JavaFX.
 *
 * Carga {@code main.fxml} con su controlador
 * {@link MainController} y abre la ventana principal.
 */
public class App extends Application {

    @Override
    public void start(Stage escenario) throws Exception {
        FXMLLoader cargador = new FXMLLoader(
                getClass().getResource("/com/reservas/ui/main.fxml"));
        Parent raiz = cargador.load();
        Scene escena = new Scene(raiz, 960, 640);
        escena.getStylesheets().add(
                getClass().getResource("/com/reservas/ui/styles.css").toExternalForm());
        escenario.setTitle("Reservas de canchas de básquetbol — Solana (devnet)");
        escenario.setScene(escena);
        escenario.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
