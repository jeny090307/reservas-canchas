package com.reservas.solana;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.reservas.solana.model.EstadoReserva;
import com.reservas.solana.model.Reserva;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import org.p2p.solanaj.core.PublicKey;

/**
 * Pruebas unitarias del cliente Java. Son pruebas puras, sin red:
 * no necesitan devnet ni un programa desplegado.
 *
 * Cubren:
 *  - que la derivación de PDA usa exactamente las seeds del programa
 *    (misma entrada -> misma PDA; distinta hora -> distinta PDA),
 *  - que el discriminador Anchor calculado en Java coincide con la IDL,
 *  - que la regla de cancelación (> 2 horas) se aplica igual que
 *    on-chain, y
 *  - que la decodificación Borsh de una cuenta Reserva es correcta.
 */
class ReservaClientTest {

    private static final PublicKey PROGRAM_ID =
            new PublicKey(SolanaConfig.PROGRAM_ID_POR_DEFECTO);

    // Clave pública de ejemplo (32 bytes en Base58).
    private static final PublicKey CANCHA =
            new PublicKey("11111111111111111111111111111111");

    @Test
    void derivarReservaEsDeterminista() {
        PublicKey.ProgramDerivedAddress primera =
                PdaUtils.derivarReserva(CANCHA, "2026-11-28", 18, PROGRAM_ID);
        PublicKey.ProgramDerivedAddress segunda =
                PdaUtils.derivarReserva(CANCHA, "2026-11-28", 18, PROGRAM_ID);
        assertEquals(primera.getAddress(), segunda.getAddress());
        assertEquals(primera.getNonce(), segunda.getNonce());
    }

    @Test
    void derivarReservaCambiaConLaHora() {
        PublicKey a18 = PdaUtils.derivarReserva(CANCHA, "2026-11-28", 18, PROGRAM_ID).getAddress();
        PublicKey a19 = PdaUtils.derivarReserva(CANCHA, "2026-11-28", 19, PROGRAM_ID).getAddress();
        assertNotEquals(a18, a19, "Dos horarios distintos no pueden compartir PDA");
    }

    @Test
    void derivarReservaCambiaConLaFechaYLaCancha() {
        PublicKey base = PdaUtils.derivarReserva(CANCHA, "2026-11-28", 18, PROGRAM_ID).getAddress();
        PublicKey otraFecha = PdaUtils.derivarReserva(CANCHA, "2026-11-29", 18, PROGRAM_ID).getAddress();
        assertNotEquals(base, otraFecha);
    }

    @Test
    void horaFueraDeRangoRechazada() {
        try {
            PdaUtils.derivarReserva(CANCHA, "2026-11-28", 24, PROGRAM_ID);
            throw new AssertionError("La hora 24 debería haber sido rechazada");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("0 y 23"));
        }
    }

    @Test
    void discriminadorCoincideConLaIdl() {
        // Primeros 8 bytes de SHA-256("global:crear_cancha"), igual que
        // en anchor-program/idl/reservas_canchas.json.
        assertArrayEquals(
                new byte[]{123, (byte) 140, (byte) 213, 74, (byte) 158, 26, (byte) 216, 28},
                ReservaClient.discriminador("crear_cancha"));
        assertArrayEquals(
                new byte[]{(byte) 181, (byte) 129, 72, (byte) 218, 85, 87, (byte) 163, (byte) 197},
                ReservaClient.discriminador("crear_reserva"));
        assertArrayEquals(
                new byte[]{32, (byte) 163, 113, 83, 88, (byte) 129, 105, (byte) 187},
                ReservaClient.discriminador("cancelar_reserva"));
    }

    @Test
    void cancelacionPermitidaConMasDeDosHoras() {
        long ahora = 1_800_000_000L;
        assertTrue(Reserva.esCancelacionPermitida(ahora + 3 * 3600, ahora, EstadoReserva.PENDIENTE));
        assertTrue(Reserva.esCancelacionPermitida(ahora + 3 * 3600, ahora, EstadoReserva.CONFIRMADA));
    }

    @Test
    void cancelacionRechazadaConMenosDeDosHoras() {
        long ahora = 1_800_000_000L;
        assertFalse(Reserva.esCancelacionPermitida(ahora + 3600, ahora, EstadoReserva.PENDIENTE));
        // Justo 2 horas no basta: la regla es "más de 2 horas".
        assertFalse(Reserva.esCancelacionPermitida(ahora + 2 * 3600, ahora, EstadoReserva.PENDIENTE));
        // Y si ya empezó, tampoco.
        assertFalse(Reserva.esCancelacionPermitida(ahora - 3600, ahora, EstadoReserva.PENDIENTE));
    }

    @Test
    void cancelacionRechazadaSiEstaCompletada() {
        long ahora = 1_800_000_000L;
        assertFalse(Reserva.esCancelacionPermitida(ahora + 5 * 3600, ahora, EstadoReserva.COMPLETADA));
        assertFalse(Reserva.esCancelacionPermitida(ahora + 5 * 3600, ahora, EstadoReserva.CANCELADA));
    }

    @Test
    void decodificarReservaBorsh() {
        // Construye a mano los bytes de una cuenta Reserva en layout Borsh.
        byte[] canchaBytes = new byte[32];
        byte[] usuarioBytes = new byte[32];
        usuarioBytes[31] = 7;
        byte[] fechaBytes = "2026-11-28".getBytes(StandardCharsets.UTF_8);
        ByteBuffer buffer = ByteBuffer.allocate(8 + 32 + 32 + 4 + fechaBytes.length + 1 + 8 + 1 + 1)
                .order(ByteOrder.LITTLE_ENDIAN);
        buffer.put(new byte[8]); // discriminador de Anchor
        buffer.put(canchaBytes);
        buffer.put(usuarioBytes);
        buffer.putInt(fechaBytes.length);
        buffer.put(fechaBytes);
        buffer.put((byte) 18);
        buffer.putLong(1_800_000_000L);
        buffer.put((byte) 0); // Pendiente
        buffer.put((byte) 255); // bump

        Reserva reserva = Reserva.fromBytes(buffer.array());
        assertEquals("2026-11-28", reserva.getFecha());
        assertEquals(18, reserva.getHoraInicio());
        assertEquals(1_800_000_000L, reserva.getInicioUnix());
        assertEquals(EstadoReserva.PENDIENTE, reserva.getEstado());
        assertEquals(255, reserva.getBump());
    }
}
