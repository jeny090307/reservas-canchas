package com.reservas.solana;

import org.p2p.solanaj.core.PublicKey;
import org.p2p.solanaj.rpc.RpcClient;

/**
 * Configuración del cliente: RPC de devnet y Program ID del programa
 * de reservas. Ambos se pueden sobrescribir con variables de entorno,
 * para no tener que recompilar al cambiar de red o de despliegue.
 *
 * <ul>
 *   <li>{@code SOLANA_RPC_URL}: por defecto https://api.devnet.solana.com</li>
 *   <li>{@code RESERVAS_PROGRAM_ID}: por defecto el ID de este proyecto</li>
 * </ul>
 */
public class SolanaConfig {

    public static final String PROGRAM_ID_POR_DEFECTO =
            "BaRjCPQHBAyEYu8MGLTv9vwsofnrK6BqZcPAK3kKk2tZ";

    private final String rpcUrl;
    private final PublicKey programId;

    public SolanaConfig() {
        this(
            System.getenv().getOrDefault("SOLANA_RPC_URL", "https://api.devnet.solana.com"),
            System.getenv().getOrDefault("RESERVAS_PROGRAM_ID", PROGRAM_ID_POR_DEFECTO)
        );
    }

    public SolanaConfig(String rpcUrl, String programIdBase58) {
        this.rpcUrl = rpcUrl;
        this.programId = new PublicKey(programIdBase58);
    }

    public RpcClient crearRpcClient() {
        return new RpcClient(rpcUrl);
    }

    public PublicKey getProgramId() {
        return programId;
    }

    public String getRpcUrl() {
        return rpcUrl;
    }
}
