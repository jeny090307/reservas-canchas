package com.reservas.solana.model;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Cuenta Cancha, tal como la define el programa Anchor.
 *
 * Layout Borsh (después del discriminador de 8 bytes de Anchor):
 * nombre (String), ubicacion (String), precio_por_hora (u64),
 * administrador (Pubkey, 32 bytes), activa (bool, 1 byte).
 */
public class Cancha {

    /** Espacio reservado en la cuenta, igual que Cancha::SPACE en Rust. */
    public static final int SPACE = 153;

    private final String nombre;
    private final String ubicacion;
    private final long precioPorHora;
    private final String administrador;
    private final boolean activa;

    public Cancha(String nombre, String ubicacion, long precioPorHora,
                  String administrador, boolean activa) {
        this.nombre = Objects.requireNonNull(nombre);
        this.ubicacion = Objects.requireNonNull(ubicacion);
        this.precioPorHora = precioPorHora;
        this.administrador = Objects.requireNonNull(administrador);
        this.activa = activa;
    }

    /** Decodifica los bytes de la cuenta (incluido el discriminador). */
    public static Cancha fromBytes(byte[] datos) {
        ByteBuffer buffer = ByteBuffer.wrap(datos).order(ByteOrder.LITTLE_ENDIAN);
        buffer.position(8); // discriminador de Anchor
        String nombre = leerString(buffer);
        String ubicacion = leerString(buffer);
        long precioPorHora = buffer.getLong();
        byte[] adminBytes = new byte[32];
        buffer.get(adminBytes);
        boolean activa = buffer.get() != 0;
        return new Cancha(nombre, ubicacion, precioPorHora,
                Base58Helper.encode(adminBytes), activa);
    }

    static String leerString(ByteBuffer buffer) {
        int longitud = buffer.getInt();
        byte[] bytes = new byte[longitud];
        buffer.get(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public long getPrecioPorHora() {
        return precioPorHora;
    }

    public String getAdministrador() {
        return administrador;
    }

    public boolean isActiva() {
        return activa;
    }

    @Override
    public String toString() {
        return "Cancha{nombre='" + nombre + "', ubicacion='" + ubicacion
                + "', precioPorHora=" + precioPorHora
                + ", administrador='" + administrador
                + "', activa=" + activa + "}";
    }
}
