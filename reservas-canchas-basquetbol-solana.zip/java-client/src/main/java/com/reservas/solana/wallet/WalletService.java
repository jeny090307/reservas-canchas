package com.reservas.solana.wallet;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import org.p2p.solanaj.core.Account;
import org.p2p.solanaj.core.PublicKey;

/**
 * Conexión de wallet para la demostración en devnet.
 *
 * <p>En este proyecto la "wallet" es un keypair local en formato JSON de
 * Solana CLI (un array de 64 números, como el que genera
 * {@code solana-keygen new}). El frontend JavaFX lo carga desde un
 * archivo elegido por el usuario y lo usa solo para firmar.</p>
 *
 * <p><b>Advertencias de seguridad:</b></p>
 * <ul>
 *   <li>Solo para <b>devnet</b> y con un keypair creado para las pruebas.</li>
 *   <li><b>Nunca</b> uses aquí un keypair de mainnet ni un keypair con
 *       fondos reales.</li>
 *   <li><b>Nunca</b> subas un archivo de keypair a GitHub: está cubierto
 *       por el {@code .gitignore} del repositorio.</li>
 *   <li>En una aplicación real, la wallet sería una extensión como
 *       Phantom y la clave privada nunca saldría de ella.</li>
 * </ul>
 */
public class WalletService {

    private Account cuenta;

    /** Conecta una wallet a partir de un keypair en formato JSON. */
    public PublicKey conectar(Path archivoKeypair) throws IOException {
        String contenido = Files.readString(archivoKeypair);
        JsonArray numeros = JsonParser.parseString(contenido).getAsJsonArray();
        if (numeros.size() != 64) {
            throw new IllegalArgumentException(
                    "El keypair debe tener 64 bytes (formato de solana-keygen)");
        }
        byte[] claveSecreta = new byte[64];
        for (int i = 0; i < 64; i++) {
            claveSecreta[i] = (byte) numeros.get(i).getAsInt();
        }
        this.cuenta = new Account(claveSecreta);
        return cuenta.getPublicKey();
    }

    /** Desconecta la wallet y olvida la clave en memoria. */
    public void desconectar() {
        this.cuenta = null;
    }

    public boolean estaConectado() {
        return cuenta != null;
    }

    public Optional<PublicKey> getPublicKey() {
        return cuenta == null
                ? Optional.empty()
                : Optional.of(cuenta.getPublicKey());
    }

    /**
     * La cuenta que firma las transacciones. Lanza excepción si no hay
     * wallet conectada.
     */
    public Account getCuenta() {
        if (cuenta == null) {
            throw new IllegalStateException("No hay ninguna wallet conectada");
        }
        return cuenta;
    }
}
