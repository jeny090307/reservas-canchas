package com.reservas.solana;

import java.nio.charset.StandardCharsets;
import java.util.List;
import org.p2p.solanaj.core.PublicKey;

/**
 * Derivación de PDAs. Las seeds son <b>idénticas</b> a las del programa
 * Anchor en {@code lib.rs}:
 *
 * <pre>
 * ["reserva", cancha_pubkey, fecha, hora_inicio]
 * </pre>
 *
 * donde {@code fecha} son los bytes UTF-8 de la fecha en formato
 * {@code YYYY-MM-DD} y {@code hora_inicio} es un solo byte (0-23).
 * Si una sola seed cambia, la dirección cambia: por eso esta clase es
 * el único lugar del cliente Java donde se derivan PDAs.
 */
public final class PdaUtils {

    private PdaUtils() {
    }

    /**
     * Deriva la PDA de una reserva para una cancha, fecha y hora.
     *
     * @return la dirección PDA y su bump (nonce).
     */
    public static PublicKey.ProgramDerivedAddress derivarReserva(
            PublicKey cancha, String fecha, int horaInicio, PublicKey programId) {
        if (horaInicio < 0 || horaInicio > 23) {
            throw new IllegalArgumentException("La hora de inicio debe estar entre 0 y 23");
        }
        List<byte[]> seeds = List.of(
                "reserva".getBytes(StandardCharsets.UTF_8),
                cancha.toByteArray(),
                fecha.getBytes(StandardCharsets.UTF_8),
                new byte[]{(byte) horaInicio}
        );
        return PublicKey.findProgramAddress(seeds, programId);
    }
}
