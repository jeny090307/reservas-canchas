package com.reservas.solana.model;

import java.math.BigInteger;
import java.util.Arrays;

/**
 * Codificación Base58 (alfabeto de Bitcoin, el mismo que usa Solana).
 * Se usa para convertir claves públicas de 32 bytes a su forma legible
 * y viceversa, sin depender de otra librería.
 */
public final class Base58Helper {

    private static final String ALFABETO = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    private static final BigInteger BASE = BigInteger.valueOf(58);

    private Base58Helper() {
    }

    public static String encode(byte[] entrada) {
        if (entrada.length == 0) {
            return "";
        }
        int ceros = 0;
        while (ceros < entrada.length && entrada[ceros] == 0) {
            ceros++;
        }
        BigInteger numero = new BigInteger(1, entrada);
        StringBuilder resultado = new StringBuilder();
        while (numero.compareTo(BigInteger.ZERO) > 0) {
            BigInteger[] division = numero.divideAndRemainder(BASE);
            numero = division[0];
            resultado.insert(0, ALFABETO.charAt(division[1].intValue()));
        }
        for (int i = 0; i < ceros; i++) {
            resultado.insert(0, '1');
        }
        return resultado.toString();
    }

    public static byte[] decode(String entrada) {
        BigInteger numero = BigInteger.ZERO;
        for (int i = 0; i < entrada.length(); i++) {
            int digito = ALFABETO.indexOf(entrada.charAt(i));
            if (digito < 0) {
                throw new IllegalArgumentException("Carácter Base58 inválido: " + entrada.charAt(i));
            }
            numero = numero.multiply(BASE).add(BigInteger.valueOf(digito));
        }
        byte[] bytes = numero.toByteArray();
        // BigInteger añade un byte de signo 0 al inicio cuando hace falta.
        if (bytes.length > 1 && bytes[0] == 0) {
            bytes = Arrays.copyOfRange(bytes, 1, bytes.length);
        }
        int ceros = 0;
        while (ceros < entrada.length() && entrada.charAt(ceros) == '1') {
            ceros++;
        }
        byte[] resultado = new byte[ceros + bytes.length];
        System.arraycopy(bytes, 0, resultado, ceros, bytes.length);
        return resultado;
    }
}
