package com.reservas.solana.model;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

/**
 * Cuenta Reserva, tal como la define el programa Anchor.
 *
 * Layout Borsh (después del discriminador de 8 bytes de Anchor):
 * cancha (Pubkey, 32 bytes), usuario (Pubkey, 32 bytes),
 * fecha (String), hora_inicio (u8), inicio_unix (i64),
 * estado (enum, 1 byte), bump (u8).
 *
 * La regla de cancelación vive aquí como método puro, para que el
 * cliente, el frontend y las pruebas usen exactamente la misma regla
 * que el programa on-chain: más de 2 horas de antelación y estado
 * distinto de Completada/Cancelada. La regla on-chain (Clock sysvar)
 * es la autoritativa; esta es solo una comprobación previa en el
 * cliente para no enviar transacciones que van a fallar.
 */
public class Reserva {

    /** Espacio reservado en la cuenta, igual que Reserva::SPACE en Rust. */
    public static final int SPACE = 97;

    /** Ventana de cancelación en segundos, igual que en el programa. */
    public static final long VENTANA_CANCELACION_SEGUNDOS = 2 * 3600;

    private final String cancha;
    private final String usuario;
    private final String fecha;
    private final int horaInicio;
    private final long inicioUnix;
    private final EstadoReserva estado;
    private final int bump;

    public Reserva(String cancha, String usuario, String fecha, int horaInicio,
                   long inicioUnix, EstadoReserva estado, int bump) {
        this.cancha = Objects.requireNonNull(cancha);
        this.usuario = Objects.requireNonNull(usuario);
        this.fecha = Objects.requireNonNull(fecha);
        this.horaInicio = horaInicio;
        this.inicioUnix = inicioUnix;
        this.estado = Objects.requireNonNull(estado);
        this.bump = bump;
    }

    /** Decodifica los bytes de la cuenta (incluido el discriminador). */
    public static Reserva fromBytes(byte[] datos) {
        ByteBuffer buffer = ByteBuffer.wrap(datos).order(ByteOrder.LITTLE_ENDIAN);
        buffer.position(8); // discriminador de Anchor
        byte[] canchaBytes = new byte[32];
        buffer.get(canchaBytes);
        byte[] usuarioBytes = new byte[32];
        buffer.get(usuarioBytes);
        String fecha = Cancha.leerString(buffer);
        int horaInicio = Byte.toUnsignedInt(buffer.get());
        long inicioUnix = buffer.getLong();
        EstadoReserva estado = EstadoReserva.desdeDiscriminante(Byte.toUnsignedInt(buffer.get()));
        int bump = Byte.toUnsignedInt(buffer.get());
        return new Reserva(Base58Helper.encode(canchaBytes),
                Base58Helper.encode(usuarioBytes), fecha, horaInicio,
                inicioUnix, estado, bump);
    }

    /**
     * Regla de cancelación (pura, sin red): la cancelación está
     * permitida solo si faltan más de 2 horas para el inicio y el
     * estado no es Completada ni Cancelada.
     */
    public static boolean esCancelacionPermitida(long inicioUnix, long ahoraUnix,
                                                 EstadoReserva estado) {
        if (estado == EstadoReserva.COMPLETADA || estado == EstadoReserva.CANCELADA) {
            return false;
        }
        return inicioUnix - ahoraUnix > VENTANA_CANCELACION_SEGUNDOS;
    }

    /** Lo mismo, aplicado a esta reserva. */
    public boolean esCancelacionPermitida(long ahoraUnix) {
        return esCancelacionPermitida(inicioUnix, ahoraUnix, estado);
    }

    public String getCancha() {
        return cancha;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getFecha() {
        return fecha;
    }

    public int getHoraInicio() {
        return horaInicio;
    }

    public long getInicioUnix() {
        return inicioUnix;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public int getBump() {
        return bump;
    }

    @Override
    public String toString() {
        return "Reserva{cancha='" + cancha + "', usuario='" + usuario
                + "', fecha='" + fecha + "', horaInicio=" + horaInicio
                + ", inicioUnix=" + inicioUnix + ", estado=" + estado
                + ", bump=" + bump + "}";
    }
}
