package com.reservas.solana.model;

/**
 * Estado de una reserva. El discriminante (0-3) es el mismo orden en el
 * que el programa Anchor define el enum {@code EstadoReserva} en Rust,
 * por eso la decodificación Borsh puede mapear el byte directamente.
 */
public enum EstadoReserva {
    PENDIENTE(0),
    CONFIRMADA(1),
    COMPLETADA(2),
    CANCELADA(3);

    private final int discriminante;

    EstadoReserva(int discriminante) {
        this.discriminante = discriminante;
    }

    public int getDiscriminante() {
        return discriminante;
    }

    public static EstadoReserva desdeDiscriminante(int valor) {
        for (EstadoReserva estado : values()) {
            if (estado.discriminante == valor) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Estado de reserva desconocido: " + valor);
    }
}
