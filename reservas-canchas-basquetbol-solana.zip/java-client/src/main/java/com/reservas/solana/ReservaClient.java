package com.reservas.solana;

import com.reservas.solana.model.Cancha;
import com.reservas.solana.model.Reserva;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import org.p2p.solanaj.core.Account;
import org.p2p.solanaj.core.AccountMeta;
import org.p2p.solanaj.core.PublicKey;
import org.p2p.solanaj.core.Transaction;
import org.p2p.solanaj.core.TransactionInstruction;
import org.p2p.solanaj.programs.SystemProgram;
import org.p2p.solanaj.rpc.RpcClient;
import org.p2p.solanaj.rpc.types.AccountInfo;

/**
 * Cliente Java del programa Anchor de reservas de canchas de básquetbol.
 *
 * Es "coherente con la IDL" en un sentido literal: cada método construye
 * la transacción con las mismas cuentas (en el mismo orden), los mismos
 * argumentos y el mismo discriminador de instrucción que describe
 * {@code anchor-program/idl/reservas_canchas.json}. El discriminador de
 * cada instrucción son los primeros 8 bytes de
 * {@code SHA-256("global:<nombre_en_snake_case>")}, igual que en Anchor.
 *
 * <p>Las cuentas de tipo PDA se derivan siempre con {@link PdaUtils},
 * nunca a mano, para que las seeds coincidan con el programa.</p>
 */
public class ReservaClient {

    private final RpcClient rpcClient;
    private final PublicKey programId;

    public ReservaClient(SolanaConfig config) {
        this.rpcClient = config.crearRpcClient();
        this.programId = config.getProgramId();
    }

    public ReservaClient(RpcClient rpcClient, PublicKey programId) {
        this.rpcClient = rpcClient;
        this.programId = programId;
    }

    // ------------------------------------------------------------------
    // Utilidades de codificación (Anchor / Borsh)
    // ------------------------------------------------------------------

    /**
     * Discriminador Anchor de una instrucción. Es package-private para
     * que las pruebas puedan comprobar que coincide con la IDL.
     */
    static byte[] discriminador(String nombreSnakeCase) {
        try {
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] hash = sha256.digest(("global:" + nombreSnakeCase).getBytes(StandardCharsets.UTF_8));
            byte[] discriminador = new byte[8];
            System.arraycopy(hash, 0, discriminador, 0, 8);
            return discriminador;
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }

    private static void escribirString(ByteArrayOutputStream out, String valor) throws IOException {
        byte[] bytes = valor.getBytes(StandardCharsets.UTF_8);
        ByteBuffer longitud = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        longitud.putInt(bytes.length);
        out.write(longitud.array());
        out.write(bytes);
    }

    private static void escribirU64(ByteArrayOutputStream out, long valor) throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putLong(valor);
        out.write(buffer.array());
    }

    private static void escribirI64(ByteArrayOutputStream out, long valor) throws IOException {
        escribirU64(out, valor);
    }

    private static TransactionInstruction instruccion(String nombreSnakeCase,
                                                      List<AccountMeta> cuentas, byte[] args) {
        try {
            ByteArrayOutputStream datos = new ByteArrayOutputStream();
            datos.write(discriminador(nombreSnakeCase));
            if (args != null) {
                datos.write(args);
            }
            return new TransactionInstruction(programId, cuentas, datos.toByteArray());
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo codificar la instrucción", e);
        }
    }

    /** Inicio de una reserva en segundos desde epoch (UTC). */
    public static long inicioUnix(String fecha, int horaInicio) {
        LocalDate dia = LocalDate.parse(fecha); // formato YYYY-MM-DD
        LocalDateTime inicio = dia.atTime(horaInicio, 0);
        return inicio.toEpochSecond(ZoneOffset.UTC);
    }

    // ------------------------------------------------------------------
    // Envío de transacciones
    // ------------------------------------------------------------------

    private String enviar(Transaction transaccion, List<Account> firmantes) {
        String blockhash = rpcClient.getApi().getRecentBlockhash();
        transaccion.setRecentBlockHash(blockhash);
        return rpcClient.getApi().sendTransaction(transaccion, firmantes);
    }

    private static Transaction transaccionCon(TransactionInstruction... instrucciones) {
        Transaction transaccion = new Transaction();
        for (TransactionInstruction ix : instrucciones) {
            transaccion.addInstruction(ix);
        }
        return transaccion;
    }

    // ------------------------------------------------------------------
    // Creación
    // ------------------------------------------------------------------

    /**
     * Crea una cancha. La cuenta de la cancha se genera con una keypair
     * nueva (no es PDA) y su administrador es quien firma.
     *
     * @return la clave pública de la cancha creada.
     */
    public PublicKey crearCancha(Account administrador, String nombre,
                                 String ubicacion, long precioPorHoraLamports) {
        Account cancha = new Account();
        long lamports = rpcClient.getApi()
                .getMinimumBalanceForRentExemption(Cancha.SPACE);
        TransactionInstruction crearCuenta = SystemProgram.createAccount(
                administrador.getPublicKey(), cancha.getPublicKey(),
                lamports, Cancha.SPACE, programId);
        TransactionInstruction ix = crearCanchaIx(
                cancha.getPublicKey(), administrador.getPublicKey(),
                nombre, ubicacion, precioPorHoraLamports);
        String firma = enviar(transaccionCon(crearCuenta, ix),
                List.of(administrador, cancha));
        System.out.println("Cancha creada: " + cancha.getPublicKey() + " (tx " + firma + ")");
        return cancha.getPublicKey();
    }

    private TransactionInstruction crearCanchaIx(PublicKey cancha, PublicKey administrador,
                                                 String nombre, String ubicacion,
                                                 long precioPorHora) {
        try {
            ByteArrayOutputStream args = new ByteArrayOutputStream();
            escribirString(args, nombre);
            escribirString(args, ubicacion);
            escribirU64(args, precioPorHora);
            return instruccion("crear_cancha", List.of(
                    new AccountMeta(cancha, true, true),
                    new AccountMeta(administrador, true, true),
                    new AccountMeta(SystemProgram.PROGRAM_ID, false, false)
            ), args.toByteArray());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Crea una reserva en estado Pendiente. Si la PDA del horario ya
     * existe, la transacción falla on-chain (doble reserva imposible).
     *
     * @return la firma de la transacción.
     */
    public String crearReserva(Account usuario, PublicKey cancha,
                               String fecha, int horaInicio) {
        PublicKey.ProgramDerivedAddress pda =
                PdaUtils.derivarReserva(cancha, fecha, horaInicio, programId);
        TransactionInstruction ix = crearReservaIx(
                pda.getAddress(), cancha, usuario.getPublicKey(),
                fecha, horaInicio, inicioUnix(fecha, horaInicio));
        return enviar(transaccionCon(ix), List.of(usuario));
    }

    private TransactionInstruction crearReservaIx(PublicKey reserva, PublicKey cancha,
                                                  PublicKey usuario, String fecha,
                                                  int horaInicio, long inicioUnix) {
        try {
            ByteArrayOutputStream args = new ByteArrayOutputStream();
            escribirString(args, fecha);
            args.write(horaInicio);
            escribirI64(args, inicioUnix);
            return instruccion("crear_reserva", List.of(
                    new AccountMeta(reserva, false, true),
                    new AccountMeta(cancha, false, true),
                    new AccountMeta(usuario, true, true),
                    new AccountMeta(SystemProgram.PROGRAM_ID, false, false)
            ), args.toByteArray());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    // ------------------------------------------------------------------
    // Modificación
    // ------------------------------------------------------------------

    /** Confirma una reserva Pendiente. Solo el administrador de la cancha. */
    public String confirmarReserva(Account administrador, PublicKey reserva, PublicKey cancha) {
        TransactionInstruction ix = instruccion("confirmar_reserva", List.of(
                new AccountMeta(reserva, false, true),
                new AccountMeta(cancha, false, false),
                new AccountMeta(administrador.getPublicKey(), true, false)
        ), null);
        return enviar(transaccionCon(ix), List.of(administrador));
    }

    /**
     * Cambia la hora de una reserva Pendiente. Solo su dueño.
     *
     * Como la hora forma parte de las seeds de la PDA, el programa
     * cierra la PDA antigua y crea la PDA del horario nuevo en la
     * misma transacción; si el horario nuevo ya está ocupado, la
     * transacción completa se revierte y no se pierde la reserva.
     */
    public String cambiarHora(Account usuario, PublicKey cancha, String fecha,
                             int horaAntigua, int horaNueva) {
        PublicKey.ProgramDerivedAddress pdaAntigua =
                PdaUtils.derivarReserva(cancha, fecha, horaAntigua, programId);
        PublicKey.ProgramDerivedAddress pdaNueva =
                PdaUtils.derivarReserva(cancha, fecha, horaNueva, programId);
        try {
            ByteArrayOutputStream args = new ByteArrayOutputStream();
            args.write(horaNueva);
            escribirI64(args, inicioUnix(fecha, horaNueva));
            TransactionInstruction ix = instruccion("cambiar_hora", List.of(
                    new AccountMeta(pdaAntigua.getAddress(), false, true),
                    new AccountMeta(pdaNueva.getAddress(), false, true),
                    new AccountMeta(cancha, false, false),
                    new AccountMeta(usuario.getPublicKey(), true, true),
                    new AccountMeta(SystemProgram.PROGRAM_ID, false, false)
            ), args.toByteArray());
            return enviar(transaccionCon(ix), List.of(usuario));
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Marca una reserva Confirmada como Completada. Solo el administrador. */
    public String completarReserva(Account administrador, PublicKey reserva, PublicKey cancha) {
        TransactionInstruction ix = instruccion("completar_reserva", List.of(
                new AccountMeta(reserva, false, true),
                new AccountMeta(cancha, false, false),
                new AccountMeta(administrador.getPublicKey(), true, false)
        ), null);
        return enviar(transaccionCon(ix), List.of(administrador));
    }

    // ------------------------------------------------------------------
    // Baja condicionada
    // ------------------------------------------------------------------

    /**
     * Cancela una reserva y cierra su cuenta (los lamports vuelven al
     * usuario). Regla del programa: solo si faltan más de 2 horas para
     * el inicio y el estado no es Completada. La comprobación previa
     * del cliente evita enviar una transacción que va a fallar, pero la
     * regla autoritativa es la on-chain (Clock sysvar).
     *
     * @throws IllegalStateException si la cancelación no está permitida.
     */
    public String cancelarReserva(Account usuario, PublicKey reserva, PublicKey cancha) {
        Reserva datos = leerReserva(reserva)
                .orElseThrow(() -> new IllegalArgumentException("La reserva no existe: " + reserva));
        long ahora = System.currentTimeMillis() / 1000;
        if (!datos.esCancelacionPermitida(ahora)) {
            throw new IllegalStateException(
                    "CancelacionNoPermitida: faltan menos de 2 horas para el inicio "
                    + "o la reserva ya está completada/cancelada.");
        }
        TransactionInstruction ix = instruccion("cancelar_reserva", List.of(
                new AccountMeta(reserva, false, true),
                new AccountMeta(cancha, false, false),
                new AccountMeta(usuario.getPublicKey(), true, true)
        ), null);
        return enviar(transaccionCon(ix), List.of(usuario));
    }

    // ------------------------------------------------------------------
    // Lectura
    // ------------------------------------------------------------------

    /** Lee una cancha por su clave pública. Vacío si la cuenta no existe. */
    public Optional<Cancha> leerCancha(PublicKey cancha) {
        AccountInfo info = rpcClient.getApi().getAccountInfo(cancha);
        if (info == null || info.getData() == null) {
            return Optional.empty();
        }
        return Optional.of(Cancha.fromBytes(Base64.getDecoder().decode(info.getData())));
    }

    /** Lee una reserva por su PDA. Vacío si la cuenta no existe (cerrada). */
    public Optional<Reserva> leerReserva(PublicKey reserva) {
        AccountInfo info = rpcClient.getApi().getAccountInfo(reserva);
        if (info == null || info.getData() == null) {
            return Optional.empty();
        }
        return Optional.of(Reserva.fromBytes(Base64.getDecoder().decode(info.getData())));
    }

    /**
     * Lista las reservas de una cancha en una fecha, derivando la PDA de
     * cada hora (0-23) y leyendo las que existen.
     *
     * <p>Limitación conocida: Solana no ofrece un índice on-chain de
     * "todas las reservas de una cancha". En producción esto se haría
     * con {@code getProgramAccounts} con filtros o con un indexador;
     * para este proyecto, derivar las 24 PDA del día es suficiente y
     * determinista.</p>
     */
    public List<Reserva> listarReservas(PublicKey cancha, String fecha) {
        List<Reserva> reservas = new ArrayList<>();
        for (int hora = 0; hora < 24; hora++) {
            PublicKey.ProgramDerivedAddress pda =
                    PdaUtils.derivarReserva(cancha, fecha, hora, programId);
            leerReserva(pda.getAddress()).ifPresent(reservas::add);
        }
        return reservas;
    }

    public PublicKey getProgramId() {
        return programId;
    }
}
