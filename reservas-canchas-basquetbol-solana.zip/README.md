# Reservas de canchas de básquetbol en Solana

Proyecto propio: aplicación descentralizada (dApp) para reservar canchas de
básquetbol, construida sobre Solana. Un usuario con wallet puede ver las
canchas disponibles, crear una reserva para una fecha y hora, y cancelarla;
el administrador de cada cancha puede confirmarla. Todas las reglas del
negocio —unicidad del horario, permisos y cierre condicionado— viven en el
programa on-chain y no en el frontend.

> **Aclaración importante sobre el lenguaje:** el programa on-chain está
> escrito en **Rust con Anchor**, porque los programas de Solana **no se
> pueden escribir en Java**. La parte en Java es el **cliente** (que
> construye y firma las transacciones exactamente como describe la IDL) y
> el **frontend JavaFX** (la interfaz gráfica con wallet). Esta es la
> arquitectura habitual en Solana: Rust/Anchor on-chain, y el lenguaje que
> se prefiera off-chain. El resto de este README explica cómo encajan las
> tres capas.

## Caso de uso

Una liga amateur gestiona varias canchas de básquetbol. Cada cancha tiene
un administrador. Los jugadores reservan un horario concreto (fecha +
hora de inicio). Una reserva pasa por los estados `Pendiente` →
`Confirmada` → `Completada`, o `Cancelada`.

Reglas que el programa impone on-chain:

1. **Un horario no se puede reservar dos veces.** La reserva es una PDA
   derivada de `["reserva", cancha, fecha, hora_inicio]`; si la PDA ya
   existe, la creación falla.
2. **Permisos.** Solo el administrador de la cancha puede crearla y
   confirmar reservas. Solo el dueño de una reserva puede cambiar su hora
   o cancelarla.
3. **Cierre condicionado.** Una reserva solo se puede cancelar (cerrar su
   cuenta y devolver los lamports al usuario) si faltan **más de 2 horas**
   para su inicio y su estado no es `Completada`. En caso contrario el
   programa rechaza la transacción con el error `CancelacionNoPermitida`.

El detalle completo está en [`docs/CASO_DE_USO.md`](docs/CASO_DE_USO.md).

## Arquitectura en 3 capas

```
┌─────────────────────────────────────────────────────────────────┐
│  javafx-frontend/  JavaFX 21                                    │
│  Ventana con wallet, lista de canchas, fecha/hora, crear,       │
│  confirmar y cancelar reservas. No contiene reglas de negocio.  │
└──────────────────────────────┬──────────────────────────────────┘
                               │ usa
┌──────────────────────────────▼──────────────────────────────────┐
│  java-client/  Java 17 + Maven + solanaj                         │
│  Cliente coherente con la IDL: deriva las PDA con las mismas    │
│  seeds que el programa, codifica cada instrucción (discriminador│
│  Anchor + Borsh) y firma con la wallet.                         │
└──────────────────────────────┬──────────────────────────────────┘
                               │ transacciones firmadas (devnet)
┌──────────────────────────────▼──────────────────────────────────┐
│  anchor-program/  Rust + Anchor 0.30 (devnet)                   │
│  Programa `reservas_canchas`: cuentas Cancha y Reserva (PDA),   │
│  instrucciones crear_cancha, crear_reserva, confirmar_reserva,  │
│  cambiar_hora, completar_reserva y cancelar_reserva.            │
└─────────────────────────────────────────────────────────────────┘
```

| Capa | Lenguaje | Qué hace |
| --- | --- | --- |
| Programa on-chain | Rust + Anchor 0.30 | Cuentas, instrucciones, permisos y reglas |
| Cliente | Java 17 + solanaj | Construye transacciones según la IDL |
| Frontend | JavaFX 21 | Interfaz gráfica, conecta la wallet |

Program ID (devnet, placeholder hasta el primer despliegue):

```
BaRjCPQHBAyEYu8MGLTv9vwsofnrK6BqZcPAK3kKk2tZ
```

> Antes de desplegar por primera vez, genera un keypair propio con
> `solana-keygen new` y sustituye este ID en `Anchor.toml`, en
> `declare_id!` de `lib.rs`, en la IDL y en `SolanaConfig.java`. El ID
> anterior es un valor de ejemplo y no corresponde a ningún programa
> desplegado.

## Estructura del repositorio

```
.
├── README.md
├── anchor-program/          # Programa Anchor (Rust)
│   ├── Anchor.toml
│   ├── Cargo.toml
│   ├── package.json
│   ├── idl/reservas_canchas.json
│   ├── migrations/deploy.ts
│   ├── programs/reservas-canchas/
│   │   ├── Cargo.toml
│   │   └── src/lib.rs
│   └── tests/reservas-canchas.ts
├── java-client/             # Cliente Java (Maven, solanaj)
│   └── src/...
├── javafx-frontend/         # Frontend JavaFX 21
│   └── src/...
├── docs/
│   ├── CASO_DE_USO.md
│   ├── DECISIONES.md
│   └── PRUEBAS_Y_EVIDENCIAS.md
└── .github/workflows/ci.yml
```

## Requisitos

- Rust + `cargo`, Solana CLI 1.18+ y Anchor CLI 0.30 (`avm install 0.30.1`)
- Node.js 18+ y `npm` (para las pruebas Anchor en TypeScript)
- JDK 17+ y Maven 3.9+ (para el cliente Java y el frontend JavaFX)
- Una wallet de devnet (Phantom o Solflare) con SOL de devnet
  (`solana airdrop 2 --url devnet`)

## Cómo correrlo en devnet

### 1. Programa Anchor

```bash
cd anchor-program
npm install
anchor build
anchor deploy --provider.cluster devnet
# Copia el Program ID que imprime el despliegue y actualízalo en
# Anchor.toml, lib.rs, la IDL y java-client (SolanaConfig.java).
anchor test --provider.cluster devnet
```

Las pruebas de `tests/reservas-canchas.ts` cubren los 5 casos de
evidencia (ver [`docs/PRUEBAS_Y_EVIDENCIAS.md`](docs/PRUEBAS_Y_EVIDENCIAS.md)).

### 2. Cliente Java

```bash
cd java-client
# Variables de entorno (o edita SolanaConfig.java):
export SOLANA_RPC_URL="https://api.devnet.solana.com"
export RESERVAS_PROGRAM_ID="BaRjCPQHBAyEYu8MGLTv9vwsofnrK6BqZcPAK3kKk2tZ"
mvn clean install
mvn test
```

### 3. Frontend JavaFX

```bash
cd java-client && mvn clean install   # instala el cliente en el repo local
cd ../javafx-frontend
mvn javafx:run
```

En la ventana: **Conectar wallet** (carga un keypair local de devnet
desde archivo, solo para la demostración), elige una cancha, fecha y
hora, y crea la reserva. El estado de cada reserva se lee directamente
de la cuenta on-chain.

> **Seguridad:** `WalletService` solo está pensado para devnet y para un
> keypair de pruebas. **Nunca** uses un keypair de mainnet ni subas un
> archivo de keypair a GitHub (está en `.gitignore`).

## Decisiones

Las decisiones de diseño —por qué la reserva es una PDA, por qué el
cambio de hora cierra la PDA antigua y crea una nueva, por qué la fecha
se guarda como texto `YYYY-MM-DD` junto a un `inicio_unix`, por qué no
hay un índice on-chain de reservas, etc.— están justificadas en
[`docs/DECISIONES.md`](docs/DECISIONES.md).

## Cómo se revisa

1. `anchor build` compila el programa y regenera la IDL; la IDL
   archivada en `anchor-program/idl/` debe coincidir con la generada.
2. `anchor test` ejecuta las pruebas on-chain (5 casos de evidencia).
3. `mvn test` en `java-client` ejecuta las pruebas unitarias de
   derivación de PDA y de la regla de cancelación (> 2 h).
4. La revisión manual se hace con la tabla de
   [`docs/PRUEBAS_Y_EVIDENCIAS.md`](docs/PRUEBAS_Y_EVIDENCIAS.md):
   cada operación (crear, leer, modificar, permisos, cierre
   condicionado) tiene su caso de prueba y su evidencia esperada.

## Licencia

MIT. Proyecto académico.
